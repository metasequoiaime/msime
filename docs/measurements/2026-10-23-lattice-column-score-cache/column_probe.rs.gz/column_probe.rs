use std::cell::RefCell;
use std::num::NonZeroUsize;
use std::sync::Arc;
use std::collections::HashSet;
use lru::LruCache;
#[derive(Hash, PartialEq, Eq)]
struct Key { memo: usize, table: usize, next: Vec<String> }
struct State { calls: u64, items: u64, hits: [u64;3], saved: [u64;3], caches: [LruCache<Arc<Key>, HashSet<String>>;3], peak_bytes: [usize;3] }
impl State { fn new() -> Self { Self { calls:0,items:0,hits:[0;3],saved:[0;3],caches:[16,64,256].map(|n| LruCache::new(NonZeroUsize::new(n).unwrap())),peak_bytes:[0;3] } } }
impl Drop for State { fn drop(&mut self) { eprintln!("COLUMN_PROBE calls={} items={} hits={:?} saved={:?} peak_bytes={:?}",self.calls,self.items,self.hits,self.saved,self.peak_bytes); } }
thread_local! { static STATE: RefCell<State> = RefCell::new(State::new()); }
pub(super) fn observe<'a>(memo: usize, table: usize, previous: &str, next: impl Iterator<Item=&'a str>) {
 STATE.with(|state| {
  let mut state=state.borrow_mut();
  let key=Arc::new(Key { memo,table,next:next.map(str::to_owned).collect() });
  state.calls+=1; state.items+=key.next.len() as u64;
  for i in 0..3 {
   if !state.caches[i].contains(&key) { state.caches[i].put(Arc::clone(&key),HashSet::new()); }
   if !state.caches[i].get_mut(&key).unwrap().insert(previous.to_owned()) { state.hits[i]+=1;state.saved[i]+=key.next.len() as u64; }
   if state.calls%4096==0 {
    let bytes=state.caches[i].iter().map(|(key,rows)| key.next.capacity()*24+key.next.iter().map(String::capacity).sum::<usize>()+rows.iter().map(|s| s.capacity()+48+key.next.len()*4).sum::<usize>()).sum();
    state.peak_bytes[i]=state.peak_bytes[i].max(bytes);
   }
  }
 });
}
