from pathlib import Path
import subprocess,shutil,hashlib,json
folder=Path('target/reranker-profile-evidence').resolve()
source=Path('crates/engine/src/ordering.rs')
original=source.read_bytes()
needle=b'            let neural = reranker.log_probabilities(context, &subset[..count]);\n'
assert original.count(needle)==1
insertion=b'            score_probe::observe(reranker as *const Reranker as usize, context, &subset[..count]);\n'
try:
    patched=original.replace(needle,insertion+needle)
    fallback=b'        reranker.best_where(context, texts, |index| CandidateFacts {\n'
    record=b'        let compared: Vec<&str> = (0..rows.len()).filter(|&index| answers_key(rows.get(index))).take(STATIC_RERANK_LIMIT).map(|index| texts[index]).collect();\n        if compared.len() >= 2 { score_probe::observe(reranker as *const Reranker as usize, context, &compared); }\n'
    assert patched.count(fallback)==1
    patched=patched.replace(fallback,record+fallback)
    patched += ('\n#[path = "'+str(folder/'score_probe.rs')+'"]\nmod score_probe;\n').encode()
    source.write_bytes(patched)
    (folder/'probe-production.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/engine/src/ordering.rs']))
    with (folder/'probe-build.log').open('w') as output:
        subprocess.run(['cargo','build','--locked','--release','-p','msime-input-runtime','--example','rerank_latency'],stdout=output,stderr=subprocess.STDOUT,check=True)
    shutil.copy2('target/release/examples/rerank_latency',folder/'probe-rerank_latency')
finally:
    source.write_bytes(original)
assert source.read_bytes()==original
(folder/'probe-binary.json').write_text(json.dumps({'sha256':hashlib.sha256((folder/'probe-rerank_latency').read_bytes()).hexdigest(),'source_restored':True},indent=2)+'\n')
