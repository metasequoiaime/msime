use std::cell::RefCell;
use std::collections::{HashMap, VecDeque};

const LIMITS: [usize; 5] = [1, 16, 32, 64, 128];
#[derive(Default)]
struct Session {
    context: String,
    queues: [VecDeque<Vec<String>>; 5],
}
#[derive(Default)]
struct Probe {
    sessions: HashMap<usize, Session>,
    calls: usize,
    items: usize,
    hits: [usize; 5],
}
thread_local! { static PROBE: RefCell<Probe> = RefCell::new(Probe::default()); }
pub(super) fn observe(id: usize, context: &str, texts: &[&str]) {
    PROBE.with(|probe| {
        let mut probe = probe.borrow_mut();
        let hits = {
            let session = probe.sessions.entry(id).or_default();
            if session.context != context {
                session.context.clear();
                session.context.push_str(context);
                for queue in &mut session.queues { queue.clear(); }
            }
            let mut hits = [false; 5];
            for ((queue, limit), hit) in session.queues.iter_mut().zip(LIMITS).zip(&mut hits) {
                let found = queue.iter().position(|entry| entry.len() == texts.len()
                    && entry.iter().zip(texts).all(|(left, right)| left == right));
                if let Some(at) = found {
                    let entry = queue.remove(at).unwrap();
                    queue.push_back(entry);
                    *hit = true;
                } else {
                    if queue.len() == limit { queue.pop_front(); }
                    queue.push_back(texts.iter().map(|text| (*text).to_owned()).collect());
                }
            }
            hits
        };
        probe.calls += 1;
        probe.items += texts.len();
        for (count, hit) in probe.hits.iter_mut().zip(hits) { *count += usize::from(hit); }
        eprintln!("rerank-probe,calls={},items={},sessions={},hits={:?}", probe.calls, probe.items, probe.sessions.len(), probe.hits);
    });
}
