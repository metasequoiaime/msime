from pathlib import Path
import subprocess,shutil,hashlib,json,os
folder=Path('target/reranker-profile-evidence').resolve()
source=Path('crates/engine/src/lattice/decode.rs')
original=source.read_bytes()
needle=b'                    match memo.as_deref_mut() {\n'
assert original.count(needle)==1
insertion=b'                    if let Some(memo) = memo.as_deref() { row_probe::observe(memo as *const BigramMemo as usize, Arc::as_ptr(table) as usize, previous, outgoing.clone().map(|edge| edge.word.as_str())); }\n'
try:
    patched=original.replace(needle,insertion+needle)
    patched += ('\n#[path = "'+str(folder/'row_probe.rs')+'"]\nmod row_probe;\n').encode()
    source.write_bytes(patched)
    (folder/'row-probe-production.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/engine/src/lattice/decode.rs']))
    with (folder/'row-probe-build.log').open('w') as output:
        subprocess.run(['cargo','build','--locked','--release','-p','msime-input-runtime','--example','rerank_latency'],stdout=output,stderr=subprocess.STDOUT,check=True,env={**os.environ,'CARGO_BUILD_JOBS':'4'})
    shutil.copy2('target/release/examples/rerank_latency',folder/'row-probe-rerank_latency')
finally:
    source.write_bytes(original)
assert source.read_bytes()==original
(folder/'row-probe-binary.json').write_text(json.dumps({'sha256':hashlib.sha256((folder/'row-probe-rerank_latency').read_bytes()).hexdigest(),'source_restored':True},indent=2)+'\n')
