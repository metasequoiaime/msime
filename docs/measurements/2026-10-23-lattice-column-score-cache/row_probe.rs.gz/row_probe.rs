use std::cell::RefCell;
use std::num::NonZeroUsize;
use std::sync::Arc;
use lru::LruCache;
#[derive(Hash, PartialEq, Eq)]
struct Key { memo: usize, table: usize, previous: String, next: Vec<String> }
struct State { calls: u64, items: u64, duplicates: u64, hits: [u64; 3], saved: [u64; 3], caches: [LruCache<Arc<Key>, ()>; 3], peak_bytes: [usize; 3] }
impl State { fn new() -> Self { Self { calls: 0, items: 0, duplicates: 0, hits: [0;3], saved: [0;3], caches: [64,256,1024].map(|n| LruCache::new(NonZeroUsize::new(n).unwrap())), peak_bytes:[0;3] } } }
impl Drop for State { fn drop(&mut self) { eprintln!("ROW_PROBE calls={} items={} duplicates={} hits={:?} saved={:?} peak_bytes={:?}",self.calls,self.items,self.duplicates,self.hits,self.saved,self.peak_bytes); } }
thread_local! { static STATE: RefCell<State> = RefCell::new(State::new()); }
pub(super) fn observe<'a>(memo: usize, table: usize, previous: &str, next: impl Iterator<Item=&'a str>) {
    STATE.with(|state| {
        let mut state=state.borrow_mut();
        let key=Arc::new(Key { memo, table, previous:previous.to_owned(), next:next.map(str::to_owned).collect() });
        state.calls+=1;
        state.items+=key.next.len() as u64;
        let mut seen=std::collections::HashSet::new();
        state.duplicates+=key.next.iter().filter(|word| !seen.insert(word.as_str())).count() as u64;
        for i in 0..3 {
            if state.caches[i].get(&key).is_some() { state.hits[i]+=1; state.saved[i]+=key.next.len() as u64; }
            else { state.caches[i].put(Arc::clone(&key),()); }
            if state.calls % 4096 == 0 {
                let bytes=state.caches[i].iter().map(|(key,_)| key.previous.capacity()+key.next.capacity()*std::mem::size_of::<String>()+key.next.iter().map(String::capacity).sum::<usize>()+key.next.len()*4).sum();
                state.peak_bytes[i]=state.peak_bytes[i].max(bytes);
            }
        }
    });
}
