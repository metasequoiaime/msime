from pathlib import Path
import subprocess,time,json,os
folder=Path('target/reranker-profile-evidence').resolve()
resources=Path('<resource-checkout>/target/resources/7356c4a452d8ba15475c0e57f134fccf7b7cbe267440461541c74d09b11b6ffe')
command=[str(folder/'baseline-rerank_latency'),'--resources',str(resources),'--set','resources/eval/sentences-nine-key-v1.tsv','--grid','nine']
with (folder/'baseline-profile-run.log').open('w') as output, (folder/'sample.log').open('w') as sample_output:
    child=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT)
    sampler=subprocess.Popen(['/usr/bin/sample',str(child.pid),'20','1','-file',str(folder/'baseline.sample.txt')],stdout=sample_output,stderr=subprocess.STDOUT)
    points=[]
    while child.poll() is None:
        names=[Path(n.strip()).name for n in subprocess.check_output(['ps','-axo','comm='],text=True).splitlines()]
        points.append({'load':list(os.getloadavg()),'compilers':{n:names.count(n) for n in ['cargo','rustc','clang','swift-frontend']}})
        time.sleep(1)
    sample_code=sampler.wait()
(folder/'profile-run.json').write_text(json.dumps({'command':command,'exit_code':child.returncode,'sampler_exit':sample_code,'monitor':points},indent=2)+'\n')
print('profile terminal',child.returncode,sample_code)
