use std::cell::RefCell;
use std::collections::{HashMap, HashSet, VecDeque};
const LIMITS: [usize; 4] = [16, 64, 256, 1024];
#[derive(Default)]
struct Session {
    prefix: Vec<u32>,
    previous: HashSet<Vec<u32>>,
    queues: [VecDeque<(Vec<u32>, f32)>; 4],
}
#[derive(Default)]
struct Counts {
    calls: usize,
    items: usize,
    previous: usize,
    current: usize,
    hits: [usize; 4],
    additional: [usize; 4],
    different: [usize; 4],
    additional_different: [usize; 4],
    max_ulp: [u32; 4],
    max_abs: [f32; 4],
    prefix_changes: usize,
    fallback: usize,
}
struct Probe {
    index: HashMap<char, u32>,
    sessions: HashMap<usize, Session>,
    counts: Counts,
}
impl Probe {
    fn new() -> Self {
        let path = std::env::var("MSIME_PROBE_VOCAB").expect("需要同一资源的词表");
        let words: Vec<String> = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        let index = words.iter().enumerate().filter_map(|(id, word)| {
            let mut chars = word.chars();
            match (chars.next(), chars.next()) {
                (Some(ch), None) => Some((ch, id as u32)),
                _ => None,
            }
        }).collect();
        Self { index, sessions: HashMap::new(), counts: Counts::default() }
    }
}
thread_local! { static PROBE: RefCell<Probe> = RefCell::new(Probe::new()); }
pub(super) fn observe(id: usize, window: usize, context: &str, texts: &[&str], scores: &[f32]) {
    PROBE.with(|probe| {
        let mut probe = probe.borrow_mut();
        let Probe { index, sessions, counts } = &mut *probe;
        assert_eq!(texts.len(), scores.len());
        let longest = texts.iter().map(|text| text.chars().count()).max().unwrap_or(0);
        let room = window.saturating_sub(longest + 1);
        let encoded: Vec<u32> = context.chars().map(|ch| index.get(&ch).copied().unwrap_or(1)).collect();
        let prefix = &encoded[encoded.len().saturating_sub(room)..];
        let limit = window.saturating_sub(prefix.len() + 1).max(1);
        let session = sessions.entry(id).or_default();
        if session.prefix != prefix {
            session.prefix = prefix.to_vec();
            session.previous.clear();
            for queue in &mut session.queues { queue.clear(); }
            counts.prefix_changes += 1;
        }
        let mut current = HashSet::new();
        for (item_index, (text, &score)) in texts.iter().zip(scores).enumerate() {
            let tokens: Vec<u32> = text.chars().take(limit).map(|ch| index.get(&ch).copied().unwrap_or(1)).collect();
            if tokens.is_empty() { continue; }
            let previous = session.previous.contains(&tokens);
            let same_batch = current.contains(&tokens);
            counts.previous += usize::from(previous);
            counts.current += usize::from(!previous && same_batch);
            let additional = !previous && !same_batch;
            for (slot, (queue, capacity)) in session.queues.iter_mut().zip(LIMITS).enumerate() {
                if let Some(at) = queue.iter().position(|(key, _)| key == &tokens) {
                    let entry = queue.remove(at).unwrap();
                    counts.hits[slot] += 1;
                    counts.additional[slot] += usize::from(additional);
                    if entry.1.to_bits() != score.to_bits() {
                        eprintln!("scalar-probe-difference,{}", serde_json::json!({"call": counts.calls + 1, "item": item_index, "capacity": capacity, "cached_bits": entry.1.to_bits(), "current_bits": score.to_bits()}));
                        counts.different[slot] += 1;
                        counts.additional_different[slot] += usize::from(additional);
                        if entry.1.is_finite() && score.is_finite() {
                            counts.max_abs[slot] = counts.max_abs[slot].max((entry.1 - score).abs());
                            // 当前模型的对数概率为负；同符号有限值的位差就是 ULP 距离。
                            assert_eq!(entry.1.is_sign_negative(), score.is_sign_negative());
                            counts.max_ulp[slot] = counts.max_ulp[slot].max(entry.1.to_bits().abs_diff(score.to_bits()));
                        }
                    }
                    queue.push_back(entry);
                } else {
                    if queue.len() == capacity { queue.pop_front(); }
                    queue.push_back((tokens.clone(), score));
                }
            }
            current.insert(tokens);
            counts.items += 1;
        }
        session.previous = current;
        counts.calls += 1;
        eprintln!("scalar-probe,{}", serde_json::json!({
            "calls": counts.calls, "items": counts.items, "previous": counts.previous,
            "current": counts.current, "hits": counts.hits, "additional": counts.additional,
            "different": counts.different, "additional_different": counts.additional_different,
            "max_abs": counts.max_abs, "max_ulp": counts.max_ulp,
            "prefix_changes": counts.prefix_changes, "fallback": counts.fallback,
            "sessions": sessions.len(), "capacities": LIMITS
        }));
    });
}
pub(super) fn fallback(id: usize) {
    PROBE.with(|probe| {
        let mut probe = probe.borrow_mut();
        probe.counts.fallback += 1;
        eprintln!("scalar-probe-fallback,{}", probe.counts.fallback);
        // 未观察回退评分的 token 和分数；清空诊断状态，避免误报额外命中。
        probe.sessions.remove(&id);
    });
}
